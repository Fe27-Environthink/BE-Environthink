import { Sequelize } from "sequelize";

// const db = new Sequelize("sql12623387", "sql12623387", "dTlBZL8F4e", {
//   host: "sql12.freemysqlhosting.net",
//   dialect: "mysql",
// });

const db = new Sequelize("sql12630004", "sql12630004", "Q3bCn417uP", {
  host: "sql12.freemysqlhosting.net",
  dialect: "mysql",
});

export default db;