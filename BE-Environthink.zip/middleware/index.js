import authMiddleware from "./authMiddleware.js";
import verifySignUp from "./verifySignUp.js";

export default {
  authMiddleware,
  verifySignUp,
};
